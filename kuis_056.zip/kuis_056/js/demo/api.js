// ===== Helper API Rental PS =====
const BASE_URL = 'https://api.melangkah.my.id';

async function apiRequest(path, method = 'GET', body = null) {
    const opt = { method: method, headers: {} };
    if (body) {
        opt.headers['Content-Type'] = 'application/json';
        opt.body = JSON.stringify(body);
    }
    const res = await fetch(BASE_URL + path, opt);
    const text = await res.text();
    let data;
    try { data = JSON.parse(text); } catch (e) { data = { message: text }; }
    if (!res.ok) throw new Error((data && data.message) || ('HTTP ' + res.status));
    return data;
}

// Ambil array dari berbagai kemungkinan bentuk response
function toList(res) {
    if (Array.isArray(res)) return res;
    if (res && typeof res === 'object') {
        const keys = ['data', 'records', 'result', 'results', 'items', 'unit', 'transaksi'];
        for (const k of keys) {
            if (Array.isArray(res[k])) return res[k];
            if (res[k] && typeof res[k] === 'object') {
                const inner = toList(res[k]);
                if (inner.length) return inner;
            }
        }
    }
    return [];
}

// Ambil 1 objek dari response detail
function toObj(res) {
    if (Array.isArray(res)) return res[0] || {};
    if (res && res.data) return Array.isArray(res.data) ? (res.data[0] || {}) : res.data;
    return res || {};
}

function esc(s) {
    return String(s === null || s === undefined ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;')
        .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function rupiah(n) {
    return 'Rp ' + new Intl.NumberFormat('id-ID').format(Number(n) || 0);
}

function showAlert(msg, type = 'success') {
    const box = document.getElementById('alertBox');
    if (!box) return alert(msg);
    box.innerHTML = '<div class="alert alert-' + type + ' alert-dismissible fade show" role="alert">' +
        esc(msg) + '<button type="button" class="close" data-dismiss="alert">&times;</button></div>';
}

function badgeStatus(s) {
    const map = { 'Tersedia': 'success', 'Disewa': 'warning', 'Maintenance': 'secondary',
                  'Berjalan': 'warning', 'Aktif': 'warning', 'Selesai': 'success', 'Batal': 'danger' };
    return '<span class="badge badge-' + (map[s] || 'info') + ' p-1 px-2">' + esc(s) + '</span>';
}

// Re-init DataTable setelah isi tbody diganti
function renderTable(tbodyHtml) {
    if ($.fn.DataTable.isDataTable('#dataTable')) $('#dataTable').DataTable().destroy();
    $('#dataTable tbody').html(tbodyHtml);
    $('#dataTable').DataTable();
}
